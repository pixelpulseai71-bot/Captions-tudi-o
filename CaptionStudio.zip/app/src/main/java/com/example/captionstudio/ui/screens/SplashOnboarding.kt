package com.example.captionstudio.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.captionstudio.ui.components.*
import com.example.captionstudio.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var progress by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (progress < 1f) {
            delay(30)
            progress += 0.02f
        }
        onDone()
    }
    Column(
        Modifier.fillMaxSize().background(Black),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(140.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(GoldLight, Gold, GoldDark))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, null, tint = Black, modifier = Modifier.size(64.dp))
        }
        Spacer(Modifier.height(24.dp))
        Text("Remove. Create. Captivate.", color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(32.dp))
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.width(180.dp),
            color = Gold,
            trackColor = Surface2
        )
    }
}

private data class OnbPage(val title: String, val subtitle: String, val caption: String?)

private val onboardingPages = listOf(
    OnbPage("Remove Captions", "Easily remove unwanted captions from your videos using powerful AI.", null),
    OnbPage("Create Captions", "Add stylish captions, auto subtitles and make your videos more engaging.", "Life is a journey"),
    OnbPage("Edit & Export", "Customize fonts, colors and animations, then export in HD quality.", null)
)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { onboardingPages.size })
    val scope = rememberCoroutineScope()
    val isLast = pagerState.currentPage == onboardingPages.lastIndex

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .statusBarsPadding()
            .padding(24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onFinish) { Text("Skip", color = TextSecondary) }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.weight(1f)) { page ->
            val item = onboardingPages[page]
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                VideoPreview(
                    Modifier.fillMaxWidth(0.8f).height(300.dp),
                    caption = item.caption,
                    showPlay = item.caption == null
                )
                Spacer(Modifier.height(32.dp))
                Text(item.title, color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    item.subtitle,
                    color = TextSecondary,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            onboardingPages.indices.forEach { i ->
                val active = i == pagerState.currentPage
                Box(
                    Modifier
                        .padding(4.dp)
                        .size(if (active) 22.dp else 8.dp, 8.dp)
                        .clip(CircleShape)
                        .background(if (active) Gold else TextSecondary.copy(alpha = 0.4f))
                )
            }
        }

        GoldButton(if (isLast) "Get Started" else "Next →") {
            if (isLast) onFinish()
            else scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
        }
        Spacer(Modifier.height(16.dp))
    }
}
