package com.example.captionstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.compose.*
import com.example.captionstudio.ui.screens.*
import com.example.captionstudio.ui.theme.*

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val PROJECTS = "projects"
    const val PROFILE = "profile"
    const val IMPORT = "import"
    const val CREATE = "create"
    const val EDITOR = "editor"
    const val EXPORT = "export"
}

private data class BottomTab(val route: String, val label: String, val icon: ImageVector)

private val bottomTabs = listOf(
    BottomTab(Routes.HOME, "Home", Icons.Default.Home),
    BottomTab(Routes.PROJECTS, "Projects", Icons.Default.List),
    BottomTab(Routes.PROFILE, "Profile", Icons.Default.Person)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CaptionStudioTheme {
                CaptionStudioApp()
            }
        }
    }
}

@Composable
fun CaptionStudioApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: ""
    val showBottomBar = bottomTabs.any { it.route == route }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Surface1) {
                    bottomTabs.forEach { tab ->
                        NavigationBarItem(
                            selected = route == tab.route,
                            onClick = {
                                nav.navigate(tab.route) {
                                    popUpTo(Routes.HOME)
                                    launchSingleTop = true
                                }
                            },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Black,
                                selectedTextColor = Gold,
                                indicatorColor = Gold,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Routes.SPLASH,
            modifier = Modifier.padding(padding)
        ) {
            composable(Routes.SPLASH) {
                SplashScreen {
                    nav.navigate(Routes.ONBOARDING) { popUpTo(Routes.SPLASH) { inclusive = true } }
                }
            }
            composable(Routes.ONBOARDING) {
                OnboardingScreen {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                }
            }
            composable(Routes.HOME) {
                HomeScreen(
                    onImport = { nav.navigate(Routes.IMPORT) },
                    onProjects = { nav.navigate(Routes.PROJECTS) }
                )
            }
            composable(Routes.PROJECTS) { ProjectsScreen() }
            composable(Routes.PROFILE) { ProfileScreen() }
            composable(Routes.IMPORT) {
                ImportScreen(
                    onPicked = { nav.navigate(Routes.CREATE) },
                    onBack = { nav.popBackStack() }
                )
            }
            composable(Routes.CREATE) {
                CreateCaptionsScreen(
                    onBack = { nav.popBackStack() },
                    onNext = { nav.navigate(Routes.EDITOR) }
                )
            }
            composable(Routes.EDITOR) {
                CaptionEditorScreen(
                    onBack = { nav.popBackStack() },
                    onNext = { nav.navigate(Routes.EXPORT) }
                )
            }
            composable(Routes.EXPORT) {
                ExportScreen(
                    onBack = { nav.popBackStack() },
                    onExport = { nav.popBackStack(Routes.HOME, false) }
                )
            }
        }
    }
}
