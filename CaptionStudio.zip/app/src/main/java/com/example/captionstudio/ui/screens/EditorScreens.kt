package com.example.captionstudio.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.captionstudio.ui.components.*
import com.example.captionstudio.ui.theme.*

@Composable
fun CreateCaptionsScreen(onBack: () -> Unit, onNext: () -> Unit) {
    var autoSubs by remember { mutableStateOf(true) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        TopBar("Create Captions", onBack)
        VideoPreview(
            Modifier.fillMaxWidth().height(220.dp),
            caption = "Life is a journey",
            showPlay = true
        )
        Spacer(Modifier.height(20.dp))
        GoldCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto Subtitles", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Generate captions from audio", color = TextSecondary, fontSize = 12.sp)
                }
                Switch(
                    checked = autoSubs,
                    onCheckedChange = { autoSubs = it },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Black,
                        checkedTrackColor = Gold
                    )
                )
            }
            Spacer(Modifier.height(8.dp))
            SettingRow("Language", "Hindi (हिन्दी)")
            SettingRow("Subtitle Style", "Modern")
        }
        Spacer(Modifier.weight(1f))
        GoldButton("Generate Captions", onClick = onNext)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun CaptionEditorScreen(onBack: () -> Unit, onNext: () -> Unit) {
    var text by remember { mutableStateOf("Life is a journey") }
    var tab by remember { mutableIntStateOf(0) }
    var colorIndex by remember { mutableIntStateOf(1) }
    var size by remember { mutableFloatStateOf(16f) }

    val tabs = listOf("Text", "Style", "Animation", "Position")
    val palette = listOf(
        Color.White, Gold, Color(0xFFFF70B0), Color(0xFF8A5CFF),
        Color(0xFF3AA0FF), Color(0xFF26D6A8), Color(0xFFFF7A2F)
    )

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        TopBar(
            "Caption Editor",
            onBack,
            actions = {
                IconButton(onClick = onNext) { Icon(Icons.Default.Check, null, tint = Gold) }
            }
        )
        VideoPreview(
            Modifier.fillMaxWidth().height(200.dp),
            caption = text,
            captionColor = palette[colorIndex],
            captionSize = size.sp,
            showPlay = false
        )

        TabRow(
            selectedTabIndex = tab,
            containerColor = Surface1,
            contentColor = Gold,
            modifier = Modifier.padding(top = 12.dp)
        ) {
            tabs.forEachIndexed { i, t ->
                Tab(
                    selected = tab == i,
                    onClick = { tab = i },
                    text = { Text(t, color = if (tab == i) Gold else TextSecondary) }
                )
            }
        }

        Column(Modifier.padding(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Caption text") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Gold,
                    unfocusedBorderColor = GoldDark,
                    focusedLabelColor = Gold,
                    cursorColor = Gold,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )
            Text("Color", color = TextSecondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                palette.forEachIndexed { i, c ->
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(c)
                            .border(if (i == colorIndex) 2.dp else 0.dp, Gold, CircleShape)
                            .clickable { colorIndex = i }
                    )
                }
            }
            Text("Text Size: ${size.toInt()}", color = TextSecondary, fontSize = 13.sp)
            Slider(
                value = size,
                onValueChange = { size = it },
                valueRange = 10f..40f,
                colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold)
            )
        }

        Spacer(Modifier.weight(1f))
        GoldButton("Next →", onClick = onNext)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun ExportScreen(onBack: () -> Unit, onExport: () -> Unit) {
    var res by remember { mutableStateOf("720P") }
    var ratio by remember { mutableStateOf("9:16") }
    var save by remember { mutableStateOf(true) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        TopBar("Export Video", onBack)
        VideoPreview(Modifier.fillMaxWidth().height(220.dp), showPlay = true)
        Spacer(Modifier.height(20.dp))

        Text("Resolution", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("720P", "1080P").forEach { r ->
                ChoiceChip(r, r == res, Modifier.weight(1f)) { res = r }
            }
        }
        Spacer(Modifier.height(20.dp))

        Text("Aspect Ratio", color = Color.White, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf("9:16", "16:9", "1:1").forEach { r ->
                ChoiceChip(r, r == ratio, Modifier.weight(1f)) { ratio = r }
            }
        }
        Spacer(Modifier.height(20.dp))

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Save to Gallery", color = Color.White, modifier = Modifier.weight(1f))
            Switch(
                checked = save,
                onCheckedChange = { save = it },
                colors = SwitchDefaults.colors(checkedThumbColor = Black, checkedTrackColor = Gold)
            )
        }

        Spacer(Modifier.weight(1f))
        GoldButton("Watch Ad & Export", onClick = onExport)
        Spacer(Modifier.height(8.dp))
        Text(
            "Watch an ad to unlock export (free)",
            color = TextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(20.dp))
    }
}
