package com.example.captionstudio.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.captionstudio.ui.components.*
import com.example.captionstudio.ui.theme.*

@Composable
fun HomeScreen(onImport: () -> Unit, onProjects: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .background(Black)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Column {
            Text("Welcome Back!", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("What would you like to do today?", color = TextSecondary, fontSize = 14.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FeatureCard("Remove Captions", "Clean your video from unwanted text.", Modifier.weight(1f), onImport)
            FeatureCard("Create Captions", "Add subtitles & stylish text.", Modifier.weight(1f), onImport)
        }

        Text("Quick Tools", color = Color.White, fontWeight = FontWeight.SemiBold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickTool("Auto Subtitles", Icons.Default.Edit, Modifier.weight(1f), onImport)
            QuickTool("Text Style", Icons.Default.Star, Modifier.weight(1f), onImport)
            QuickTool("Enhancer", Icons.Default.Build, Modifier.weight(1f), onImport)
            QuickTool("More", Icons.Default.MoreVert, Modifier.weight(1f), onImport)
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Recent Projects",
                color = Color.White,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = onProjects) { Text("View All >", color = Gold, fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            repeat(3) { VideoPreview(Modifier.weight(1f).height(90.dp), showPlay = true) }
        }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF2A2110), Surface1)))
            .border(1.dp, Gold.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Icon(
            Icons.Default.Edit,
            null,
            tint = Black,
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Gold)
                .padding(10.dp)
        )
        Spacer(Modifier.height(14.dp))
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun QuickTool(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(6.dp))
        Text(label, color = TextSecondary, fontSize = 11.sp)
    }
}

@Composable
fun ImportScreen(onPicked: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding()) {
        com.example.captionstudio.ui.components.TopBar("Import Video", onBack)
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ImportOption("From Gallery", Icons.Default.Add, Modifier.weight(1f), onPicked)
                ImportOption("From Camera", Icons.Default.PlayArrow, Modifier.weight(1f), onPicked)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                ImportOption("YouTube Link", Icons.Default.Share, Modifier.weight(1f), onPicked)
                ImportOption("Recent Files", Icons.Default.DateRange, Modifier.weight(1f), onPicked)
            }
            Spacer(Modifier.height(10.dp))
            GoldCard {
                Text("Supported Formats", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text("MP4, MOV, AVI, MKV, 3GP", color = TextSecondary, fontSize = 13.sp)
                Text("Max Size: 500MB", color = TextSecondary, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun ImportOption(label: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier
            .height(120.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Surface1)
            .border(1.dp, Gold.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(8.dp))
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

private val sampleProjects = listOf(
    "Beach_Video.mp4" to "00:15 • 1080p",
    "Mountain_View.mp4" to "00:24 • 720p",
    "Vlog_2025.mp4" to "01:12 • 1080p"
)

@Composable
fun ProjectsScreen() {
    val filters = listOf("All", "Edited", "Created")
    var selected by remember { mutableStateOf("All") }

    Column(Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(20.dp)) {
        Text("My Projects", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            filters.forEach { f ->
                FilterChip(
                    selected = selected == f,
                    onClick = { selected = f },
                    label = { Text(f) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Gold,
                        selectedLabelColor = Black,
                        containerColor = Surface1,
                        labelColor = TextSecondary
                    )
                )
            }
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(sampleProjects) { (name, meta) -> ProjectRow(name, meta) }
        }
    }
}

@Composable
fun ProjectRow(name: String, meta: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        VideoPreview(Modifier.size(90.dp, 60.dp), showPlay = false)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(meta, color = TextSecondary, fontSize = 12.sp)
        }
        Icon(Icons.Default.MoreVert, null, tint = TextSecondary)
    }
}

@Composable
fun ProfileScreen() {
    Column(
        Modifier.fillMaxSize().background(Black).statusBarsPadding().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Profile", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(GoldLight, Gold, GoldDark)))
            )
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Creator", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("Free Plan", color = Gold, fontSize = 13.sp)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatBox("5", "Projects", Modifier.weight(1f))
            StatBox("2.4K", "Downloads", Modifier.weight(1f))
            StatBox("4.8", "Rating", Modifier.weight(1f))
        }
        listOf("My Videos", "Saved Templates", "Watch History", "Settings", "Help & Support")
            .forEach { MenuRow(it) }
    }
}

@Composable
fun StatBox(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .border(1.dp, Gold.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .padding(vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value, color = Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, color = TextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun MenuRow(label: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Surface1)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Icon(Icons.Default.KeyboardArrowRight, null, tint = Gold)
    }
}
