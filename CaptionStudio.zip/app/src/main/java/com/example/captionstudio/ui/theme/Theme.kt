package com.example.captionstudio.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Gold = Color(0xFFFFC233)
val GoldLight = Color(0xFFFFE08A)
val GoldDark = Color(0xFFB8860B)
val Black = Color(0xFF0A0A0A)
val Surface1 = Color(0xFF151515)
val Surface2 = Color(0xFF1E1E1E)
val TextSecondary = Color(0xFFA6A6A6)

private val DarkColors = darkColorScheme(
    primary = Gold,
    onPrimary = Black,
    secondary = GoldLight,
    background = Black,
    onBackground = Color.White,
    surface = Surface1,
    onSurface = Color.White,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextSecondary,
    outline = GoldDark
)

@Composable
fun CaptionStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
